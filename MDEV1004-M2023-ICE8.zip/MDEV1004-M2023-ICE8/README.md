# MDEV1004 - M2023 - ICE 5
Demo project for In-Class Exercise 5 in Summer 2023 Semester at Georgian College 