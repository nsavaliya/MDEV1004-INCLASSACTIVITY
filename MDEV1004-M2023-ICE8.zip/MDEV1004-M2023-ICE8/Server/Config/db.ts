let localURI= 'mongodb://127.0.0.1:27017/movies';
let remoteURI='mongodb+srv://nsavaliya:hBiHE2GKc9ifWBBf@moviecluster.bpwbiyk.mongodb.net/movies';
let secret  = 'SomeSecret';
export default {
    localURI: localURI,
    remoteURI: remoteURI,
    secret: secret
}